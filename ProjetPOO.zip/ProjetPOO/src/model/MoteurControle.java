/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import util.CategorieControle;

public class MoteurControle extends ElementControle {

    @Override
    public CategorieControle getCategorie() {
        return CategorieControle.MOTEUR;
    }
  }
